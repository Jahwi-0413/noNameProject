create
    definer = root@localhost procedure keyword_search(IN tableName varchar(10), IN keyword varchar(30))
BEGIN
	if tableName='tour' then
		select distinct * from 창의프로젝트.tour where tourName like concat('%',keyword,'%') or classification like concat('%',keyword,'%')
			or fullAddress like concat('%',keyword,'%');
	elseif tableName='restaurant' then
    	select distinct * from 창의프로젝트.restaurant where restaurantName like concat('%',keyword,'%') or mainMenu like concat('%',keyword,'%')
			or fullAddress like concat('%',keyword,'%');
	elseif tableName='lodgment' then
		select distinct * from 창의프로젝트.lodgment where lodgmentName like concat('%',keyword,'%') or classification
			or fullAddress like concat('%',keyword,'%');
        end if;
END;

